.. _whatsnew:

**********
What's New
**********

These are new features and improvements of note in each release.

.. include:: whatsnew/v0.3.3.2.rst
.. include:: whatsnew/v0.3.3.1.rst
.. include:: whatsnew/v0.3.3.rst
.. include:: whatsnew/v0.3.0.rst
.. include:: whatsnew/v0.2.4.rst
.. include:: whatsnew/v0.2.3.rst
.. include:: whatsnew/v0.2.2.rst
.. include:: whatsnew/v0.2.1.rst
.. include:: whatsnew/v0.2.0.rst
.. include:: whatsnew/v0.1.1.rst
.. include:: whatsnew/v0.1.0.rst
.. include:: whatsnew/v0.0.5.rst
.. include:: whatsnew/v0.0.4.rst
.. include:: whatsnew/v0.0.3.rst
.. include:: whatsnew/v0.0.2.rst
.. include:: whatsnew/v0.0.1.rst

