.. _variables_style_rules:

Variables and Symbols
=====================

Here is a convention on consistent variable names throughout the library:

